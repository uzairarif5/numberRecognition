import numpy as np
import tkinter as tk
import math
import os
import threading

firstArrSize = 784 #remember to make it a multiple of 14, and set the size of the board as well
firstArr = np.zeros(firstArrSize,dtype=np.float16)
secondArrSize = 256
secondArr = np.ndarray(secondArrSize,dtype=np.float16)
thirdArrSize = 128
thirdArr = np.ndarray(thirdArrSize,dtype=np.float16)
outputs = np.ndarray(10,dtype=np.float16)
correctValues = np.ndarray(10,dtype=np.int16)

window = tk.Tk()

drawingFrame = tk.Frame(window,borderwidth=2,relief='solid')
drawingFrame.grid(row=0,column=0,padx=10,pady=15)
board = tk.Canvas(drawingFrame,height=196,width=196,highlightthickness=0,bg='white')
board.grid(row=0,column=0)
buttonFrame = tk.Frame(window,padx=10,pady=10)
buttonFrame.grid(row=0,column=1)

dir_path = os.path.dirname(os.path.realpath(__file__))
file = open(dir_path + "/link12.npy",'rb')
link12 = np.load(file)
file.close()
file = open(dir_path + "/link23.npy",'rb')
link23 = np.load(file)
file.close()
file = open(dir_path + "/link34.npy",'rb')
link34 = np.load(file)
file.close()
file = open(dir_path + "/baises2.npy",'rb')
baises2 = np.load(file)
file.close()
file = open(dir_path + "/baises3.npy",'rb')
baises3 = np.load(file)
file.close()
file = open(dir_path + "/baises4.npy",'rb')
baises4 = np.load(file)
file.close()

def numClick():
    global firstArr
    global errorSum
    global totalErrorSum
    global outputText

    outputText = ''
    for y in range(28):
        start = y *28
        outputText += str(firstArr[start:start+28].astype("int16")).replace("0","_").replace("1","#") + '\n'
    fAnew = firstArr.reshape((28,28))
    for y in range(27):
        for x in range(27):
            if(fAnew[y][x] == 1 or fAnew[y][x] == 0.7):
                if x > 0 and fAnew[y][x-1] == 0:
                    fAnew[y][x-1] = 0.21
                    fAnew[y][x] = 0.7
                if x < 27 and fAnew[y][x+1]==0:
                    fAnew[y][x+1] = 0.21
                    fAnew[y][x] = 0.7
                if(y > 0 and fAnew[y+1][x]==0):
                    fAnew[y+1][x] = 0.21
                    fAnew[y][x] = 0.7
                if(y<27 and fAnew[y-1][x]==0):
                    fAnew[y-1][x] = 0.21
                    fAnew[y][x] = 0.7
    firstArr = fAnew.reshape(784)
    #setting second layer from the values of the first layers and their weights
    secondArr = 1/(1 + np.exp(-((firstArr @ link12)+baises2)))
    #setting third layer from the values of the second layers and their weights
    thirdArr = 1/(1 + np.exp(-((secondArr @ link23)+baises3)))
    #setting fourth layer from the values of the third layers and their weights
    outputs = 1/(1 + np.exp(-((thirdArr @ link34)+baises4)))
    #check values and output
    finalValue = np.max(outputs)
    print(outputText + '\noutput: ', np.where(outputs == finalValue)[0][0])

#click events for drawing board
mouseClicked = False
def click(event):
    global mouseClicked
    mouseClicked = True
    x, y = math.floor((event.x)/7), math.floor((event.y)/7)
    xPixel, yPixel = x*7, y*7
    firstArr[x+(28*y)] = 1
    event.widget.create_rectangle(xPixel,yPixel,xPixel+7,yPixel+7,fill='black')
    if(x > 0):
        firstArr[x-1+(28*y)] = 1
        event.widget.create_rectangle(xPixel-7,yPixel,xPixel,yPixel+7,fill='black')
    if(x < 27):
        firstArr[x+1+(28*y)] = 1
        event.widget.create_rectangle(xPixel+7,yPixel,xPixel+14,yPixel+7,fill='black')
    if(y > 0):
        firstArr[x+(28*(y-1))] = 1
        event.widget.create_rectangle(xPixel,yPixel-7,xPixel+7,yPixel,fill='black')
    if(y < 27):
        firstArr[x+(28*(y+1))] = 1
        event.widget.create_rectangle(xPixel,yPixel+7,xPixel+7,yPixel+14,fill='black')
def move(event):
    global mouseClicked
    if mouseClicked:
        x, y = math.floor((event.x)/7), math.floor((event.y)/7)
        xPixel, yPixel = x*7, y*7
        firstArr[x+(28*y)] = 1
        event.widget.create_rectangle(xPixel,yPixel,xPixel+7,yPixel+7,fill='black')
        if(x > 0):
            firstArr[x-1+(28*y)] = 1
            event.widget.create_rectangle(xPixel-7,yPixel,xPixel,yPixel+7,fill='black')
        if(x < 27):
            firstArr[x+1+(28*y)] = 1
            event.widget.create_rectangle(xPixel+7,yPixel,xPixel+14,yPixel+7,fill='black')
        if(y > 0):
            firstArr[x+(28*(y-1))] = 1
            event.widget.create_rectangle(xPixel,yPixel-7,xPixel+7,yPixel,fill='black')
        if(y < 27):
            firstArr[x+(28*(y+1))] = 1
            event.widget.create_rectangle(xPixel,yPixel+7,xPixel+7,yPixel+14,fill='black')
def release(event):
    global mouseClicked
    mouseClicked = False
def exit(event):
    global mouseClicked
    mouseClicked = False

board.bind('<Button-1>', click)
board.bind('<Motion>', move)
board.bind('<ButtonRelease-1>', release)
board.bind('<Leave>', exit)

#event when clicking button
def buttonclick(event):
    thread = threading.Thread(target=numClick)
    thread.start()
    button.configure(state=tk.DISABLED)
    button2.configure(state=tk.DISABLED)
    board.delete("all")
    def enableEm():
        global firstArr
        thread.join()
        firstArr = np.zeros(firstArrSize,dtype=np.float16)
        button.configure(state=tk.NORMAL)
        button2.configure(state=tk.NORMAL)
    thread2 = threading.Thread(target=enableEm)
    thread2.start()


#create buttons
button = tk.Button(buttonFrame, text='check',font=('Helvetica', '12'),highlightthickness=0,borderwidth=2,width=5,compound=tk.CENTER)
button.grid(row=1,pady=5,column=0)
button.bind("<Button-1>",buttonclick)

def reset(event):
    global firstArr
    board.delete("all")
    firstArr = np.zeros(firstArrSize,dtype=np.float16)

button2 = tk.Button(buttonFrame, text='clear',font=('Helvetica', '10'),highlightthickness=0,borderwidth=2,compound=tk.CENTER)
button2.grid(row=2,column=0)
button2.bind("<Button-1>",reset)

window.mainloop()